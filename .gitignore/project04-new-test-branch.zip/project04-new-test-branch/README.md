# project04

for morning question
if yes: return true
if no: return false

if morning question returns true --> go to or append question toy
if false --> go to or append question hair

for toy question
if be fine: return true
if get mad: return false

if toy question returns true --> go to or append question friday
if false --> go to or append top shelf hair

for hair question
if big: return true
if not big: return false

if hair question returns true --> go to or append question shelf
if false --> go to or append question friday

Hello there! - Joey
